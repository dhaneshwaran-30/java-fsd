import org.openqa.selenium.*;

import org.openqa.selenium.chrome.ChromeDriver;

public class HelloWorldSelenium {

	public static void main(String[] args) {
		
		WebDriver driver = (WebDriver) new ChromeDriver(); // new FirefoxDriver();
		
		String baseUrl = "https://www.google.com";
		
		driver.get(baseUrl);		

	}

}