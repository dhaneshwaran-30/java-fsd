package com.ecommerce.test;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class ActionsDemo {
	
	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver(); // new FirefoxDriver();
	}
	
	static void demoMouseActions(WebDriver driver) throws InterruptedException {
		String baseUrl = "file:///C:/Users/HP/eclipse-workspace-EE-phase3/hello-selenium/src/main/resources/test.html";

		driver.get(baseUrl);
		
		WebElement buttonElement = driver.findElement(By.id("dblButton"));
		
		Actions actions = new Actions(driver);
		
		actions.doubleClick(buttonElement).perform();
	}

}